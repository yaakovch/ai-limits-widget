#!/usr/bin/env bash

if [[ -n "${WTMUX_LIB_CONFIG_SH:-}" ]]; then
  return 0
fi
WTMUX_LIB_CONFIG_SH=1

source "${WTMUX_REPO_ROOT}/lib/common.sh"
source "${WTMUX_REPO_ROOT}/lib/platform.sh"
source "${WTMUX_REPO_ROOT}/lib/tailscale.sh"

WTMUX_CONFIG_LOADED_PATH=""
WTMUX_SHARED_REGISTRY_MARKER_BEGIN="# BEGIN wtmux-managed shared-registry"
WTMUX_SHARED_REGISTRY_MARKER_END="# END wtmux-managed shared-registry"
WTMUX_SHARED_REGISTRY_LOADER_VERSION="# wtmux shared-registry loader v2"

wtmux_machine_var_name() {
  local machine_id="${1//[^a-zA-Z0-9_]/_}"
  local field="${2//[^a-zA-Z0-9_]/_}"
  printf 'machine__%s__%s\n' "$machine_id" "$field"
}

wtmux_machine_field() {
  local machine_id="$1"
  local field="$2"
  local variable
  variable="$(wtmux_machine_var_name "$machine_id" "$field")"
  printf '%s\n' "${!variable-}"
}

wtmux_machine_name() {
  local machine_id="$1"
  local value
  value="$(wtmux_machine_field "$machine_id" "name")"
  printf '%s\n' "${value:-$machine_id}"
}

wtmux_machine_roles() {
  wtmux_machine_field "$1" "roles"
}

wtmux_machine_has_role() {
  local machine_id="$1"
  local role="$2"
  local roles
  roles="$(wtmux_machine_roles "$machine_id")"
  [[ " ${roles} " == *" ${role} "* ]]
}

wtmux_config_has_machine() {
  local machine_id="$1"
  local item
  for item in "${WTMUX_MACHINE_IDS[@]:-}"; do
    [[ "$item" == "$machine_id" ]] && return 0
  done
  return 1
}

wtmux_config_machine_ids() {
  printf '%s\n' "${WTMUX_MACHINE_IDS[@]:-}"
}

wtmux_machine_ids_with_role() {
  local role="$1"
  local machine_id

  for machine_id in "${WTMUX_MACHINE_IDS[@]:-}"; do
    if wtmux_machine_has_role "$machine_id" "$role"; then
      printf '%s\n' "$machine_id"
    fi
  done
}

wtmux_machine_is_wsl_host() {
  local machine_id="$1"

  wtmux_machine_has_role "$machine_id" "host" || return 1
  [[ "$(wtmux_machine_field "$machine_id" "platform")" == "wsl" ]]
}

wtmux_windows_sibling_id_for_machine() {
  local machine_id="$1"
  local base="$machine_id"

  base="${base%-ubuntu}"
  base="${base%-Ubuntu}"
  printf '%s_windows\n' "$base"
}

wtmux_windows_sibling_base_machine() {
  local windows_id="$1"
  local machine_id

  for machine_id in "${WTMUX_MACHINE_IDS[@]:-}"; do
    if wtmux_machine_is_wsl_host "$machine_id" && [[ "$(wtmux_windows_sibling_id_for_machine "$machine_id")" == "$windows_id" ]]; then
      printf '%s\n' "$machine_id"
      return 0
    fi
  done

  return 1
}

wtmux_machine_ids_with_role_and_windows_siblings() {
  local role="$1"
  local machine_id

  for machine_id in "${WTMUX_MACHINE_IDS[@]:-}"; do
    if wtmux_machine_has_role "$machine_id" "$role"; then
      printf '%s\n' "$machine_id"
      if [[ "$role" == "host" ]] && wtmux_machine_is_wsl_host "$machine_id"; then
        wtmux_windows_sibling_id_for_machine "$machine_id"
      fi
    fi
  done
}

wtmux_load_config() {
  local config_path="${1:-$(wtmux_config_path)}"

  if [[ "$WTMUX_CONFIG_LOADED_PATH" == "$config_path" ]]; then
    return 0
  fi

  if [[ ! -f "$config_path" ]]; then
    return 1
  fi

  # shellcheck disable=SC1090
  source "$config_path" || return 1
  if ! declare -p WTMUX_MACHINE_IDS >/dev/null 2>&1; then
    WTMUX_MACHINE_IDS=()
  fi
  WTMUX_CONFIG_LOADED_PATH="$config_path"
  WTMUX_LOCAL_MACHINE_ID_CACHE_INITIALIZED=0
  WTMUX_LOCAL_MACHINE_ID_CACHE=""
}

wtmux_write_default_config() {
  local config_path="${1:-$(wtmux_config_path)}"
  local template_path="${WTMUX_REPO_ROOT}/wtmux.conf"

  mkdir -p "$(dirname "$config_path")"
  if [[ -f "$template_path" ]]; then
    cp "$template_path" "$config_path"
  else
    printf 'WTMUX_MACHINE_IDS=()\n' >"$config_path"
  fi
}

wtmux_shared_registry_dir() {
  printf '%s\n' "${WTMUX_SHARED_REGISTRY_DIR:-${WTMUX_REPO_ROOT}/fleet/machines}"
}

wtmux_shared_machine_record_path() {
  local machine_id="$1"
  printf '%s/%s.json\n' "$(wtmux_shared_registry_dir)" "$machine_id"
}

wtmux_registry_tool_path() {
  printf '%s/scripts/wtmux-registry\n' "$WTMUX_REPO_ROOT"
}

wtmux_registry_cache_path() {
  printf '%s/registry/shared-registry.sh\n' "$(wtmux_cache_dir)"
}

wtmux_registry_capability() {
  local registry_dir="${1:-$(wtmux_shared_registry_dir)}"
  if command -v python3 >/dev/null 2>&1 \
    && [[ -x "$(wtmux_registry_tool_path)" ]] \
    && python3 "$(wtmux_registry_tool_path)" validate "$registry_dir" >/dev/null 2>&1; then
    printf 'json-v1\n'
  else
    printf 'legacy\n'
  fi
}

wtmux_registry_record_count() {
  local registry_dir="${1:-$(wtmux_shared_registry_dir)}"
  find "$registry_dir" -mindepth 1 -maxdepth 1 -type f -name '*.json' 2>/dev/null | wc -l | tr -d ' '
}

wtmux_load_shared_registry() {
  local registry_dir="${1:-$(wtmux_shared_registry_dir)}"
  local cache_path

  [[ -d "$registry_dir" ]] || return 0
  if ! command -v python3 >/dev/null 2>&1; then
    wtmux_warn "python3 is required for the data-only fleet registry; run ./setup.sh --install-deps"
    return 1
  fi

  cache_path="$(wtmux_registry_cache_path)"
  if ! python3 "$(wtmux_registry_tool_path)" build-cache "$registry_dir" "$cache_path" >/dev/null; then
    wtmux_warn "shared JSON registry validation failed; refusing to load Git-provided machine data"
    return 1
  fi
  # The cache is generated locally with shell quoting after all records validate.
  # shellcheck disable=SC1090
  source "$cache_path"
}

wtmux_shared_registry_source_block() {
  cat <<'EOF'
# BEGIN wtmux-managed shared-registry
# wtmux shared-registry loader v2
_wtmux_shared_registry_dir="${WTMUX_SHARED_REGISTRY_DIR:-${WTMUX_REPO_ROOT:-}/fleet/machines}"
if declare -F wtmux_load_shared_registry >/dev/null 2>&1; then
  wtmux_load_shared_registry "${_wtmux_shared_registry_dir}" || return 1
fi
unset _wtmux_shared_registry_dir
# END wtmux-managed shared-registry
EOF
}

wtmux_runtime_config_has_shared_registry_source() {
  local config_path="${1:-$(wtmux_config_path)}"
  [[ -f "$config_path" ]] || return 1
  grep -Fq "$WTMUX_SHARED_REGISTRY_MARKER_BEGIN" "$config_path"
}

wtmux_runtime_config_has_json_registry_loader() {
  local config_path="${1:-$(wtmux_config_path)}"
  [[ -f "$config_path" ]] || return 1
  grep -Fq "$WTMUX_SHARED_REGISTRY_LOADER_VERSION" "$config_path"
}

wtmux_replace_runtime_registry_block() {
  local config_path="$1"
  local temp_path
  local line
  local skipping=0
  local found_begin=0
  local found_end=0

  temp_path="$(mktemp "$(dirname "$config_path")/.wtmux.conf.XXXXXX")"
  while IFS= read -r line || [[ -n "$line" ]]; do
    if [[ "$line" == "$WTMUX_SHARED_REGISTRY_MARKER_BEGIN" ]]; then
      wtmux_shared_registry_source_block >>"$temp_path"
      skipping=1
      found_begin=1
      continue
    fi
    if [[ "$skipping" == "1" ]]; then
      if [[ "$line" == "$WTMUX_SHARED_REGISTRY_MARKER_END" ]]; then
        skipping=0
        found_end=1
      fi
      continue
    fi
    printf '%s\n' "$line" >>"$temp_path"
  done <"$config_path"

  if [[ "$found_begin" != "1" || "$found_end" != "1" || "$skipping" != "0" ]]; then
    rm -f "$temp_path"
    wtmux_warn "managed registry block is malformed in ${config_path}; refusing to rewrite it"
    return 1
  fi
  chmod --reference="$config_path" "$temp_path" 2>/dev/null || chmod 600 "$temp_path"
  mv "$temp_path" "$config_path"
}

wtmux_ensure_runtime_config_uses_shared_registry() {
  local config_path="${1:-$(wtmux_config_path)}"
  mkdir -p "$(dirname "$config_path")"

  if [[ ! -f "$config_path" ]]; then
    wtmux_write_default_config "$config_path"
  fi

  if wtmux_runtime_config_has_json_registry_loader "$config_path"; then
    return 0
  fi

  if wtmux_runtime_config_has_shared_registry_source "$config_path"; then
    wtmux_replace_runtime_registry_block "$config_path"
    return $?
  fi

  {
    printf '\n'
    wtmux_shared_registry_source_block
  } >>"$config_path"
}

wtmux_require_config() {
  local config_path="${1:-$(wtmux_config_path)}"
  if [[ ! -f "$config_path" ]]; then
    wtmux_die "config not found at ${config_path}; run ./setup.sh or 'wtmux add-machine'"
  fi
  wtmux_ensure_runtime_config_uses_shared_registry "$config_path"
  wtmux_load_config "$config_path"
}

wtmux_sanitize_machine_id() {
  wtmux_slugify "$1"
}

wtmux_validate_loaded_config() {
  local config_path="${1:-$(wtmux_config_path)}"
  local machine_id
  local machine_name
  local roles
  local platform
  local transport
  local sanitized_name
  local fallback_host
  local errors=0
  declare -A seen_ids=()
  declare -A seen_names=()

  if [[ "${#WTMUX_MACHINE_IDS[@]}" -eq 0 ]]; then
    wtmux_warn "config has no machines yet: ${config_path}"
    return 0
  fi

  for machine_id in "${WTMUX_MACHINE_IDS[@]}"; do
    machine_name="$(wtmux_machine_name "$machine_id")"
    roles="$(wtmux_machine_roles "$machine_id")"
    platform="$(wtmux_machine_field "$machine_id" "platform")"
    transport="$(wtmux_machine_field "$machine_id" "transport")"
    sanitized_name="$(wtmux_sanitize_machine_id "$machine_name")"
    fallback_host="$(wtmux_machine_field "$machine_id" "fallback_ssh_host")"

    if [[ -n "${seen_ids[$machine_id]:-}" ]]; then
      wtmux_warn "duplicate machine id: ${machine_id}"
      errors=1
    fi
    seen_ids["$machine_id"]=1

    if [[ -n "${seen_names[$sanitized_name]:-}" ]]; then
      wtmux_warn "sanitized machine name collision: ${machine_name}"
      errors=1
    fi
    seen_names["$sanitized_name"]=1

    if [[ -z "$roles" ]]; then
      wtmux_warn "machine ${machine_id} is missing roles"
      errors=1
    fi

    case "$platform" in
      linux|wsl|termux) ;;
      *)
        wtmux_warn "machine ${machine_id} has unsupported platform '${platform}'"
        errors=1
        ;;
    esac

    if [[ -z "$(wtmux_machine_field "$machine_id" "linux_username")" ]]; then
      wtmux_warn "machine ${machine_id} is missing linux_username"
      errors=1
    fi

    if wtmux_machine_has_role "$machine_id" "host"; then
      if [[ -z "$(wtmux_machine_field "$machine_id" "projects_root")" ]]; then
        wtmux_warn "host machine ${machine_id} is missing projects_root"
        errors=1
      fi

      case "$transport" in
        ""|tailscale)
          if [[ -z "$(wtmux_machine_field "$machine_id" "tailscale_node")" ]]; then
            wtmux_warn "host machine ${machine_id} uses tailscale but has no tailscale_node"
            errors=1
          fi
          ;;
        ssh)
          if [[ -z "$fallback_host" && -z "$(wtmux_machine_field "$machine_id" "fallback_ip")" ]]; then
            wtmux_warn "host machine ${machine_id} uses ssh but has no fallback_ssh_host or fallback_ip"
            errors=1
          fi
          ;;
        *)
          wtmux_warn "machine ${machine_id} has unsupported transport '${transport}'"
          errors=1
          ;;
      esac
    fi
  done

  return "$errors"
}

wtmux_validate_config_file() {
  local config_path="${1:-$(wtmux_config_path)}"
  wtmux_load_config "$config_path" || return 1
  wtmux_validate_loaded_config "$config_path"
}

wtmux_local_machine_score() {
  local machine_id="$1"
  local include_tailscale="${2:-1}"
  local score=0
  local platform
  local machine_platform
  local hostname
  local machine_name
  local current_user
  local distro
  local machine_distro
  local local_tailscale
  local machine_tailscale

  platform="$(wtmux_detect_platform)"
  machine_platform="$(wtmux_machine_field "$machine_id" "platform")"
  hostname="$(wtmux_get_hostname_short)"
  machine_name="$(wtmux_machine_name "$machine_id")"
  current_user="$(id -un)"
  distro="$(wtmux_get_wsl_distro 2>/dev/null || true)"
  machine_distro="$(wtmux_machine_field "$machine_id" "wsl_distro")"
  machine_tailscale="$(wtmux_machine_field "$machine_id" "tailscale_node")"

  [[ "$platform" == "$machine_platform" ]] && ((score += 2))
  [[ "$(wtmux_sanitize_machine_id "$hostname")" == "$(wtmux_sanitize_machine_id "$machine_name")" ]] && ((score += 3))
  [[ "$current_user" == "$(wtmux_machine_field "$machine_id" "linux_username")" ]] && ((score += 2))
  [[ -n "$distro" && -n "$machine_distro" && "$distro" == "$machine_distro" ]] && ((score += 2))
  if [[ "$include_tailscale" == "1" ]]; then
    local_tailscale="$(wtmux_local_tailscale_node 2>/dev/null || true)"
    [[ -n "$local_tailscale" && -n "$machine_tailscale" && "$local_tailscale" == "$machine_tailscale" ]] && ((score += 5))
  fi

  printf '%s\n' "$score"
}

wtmux_detect_local_machine_id() {
  local forced="${WTMUX_LOCAL_MACHINE_ID:-}"
  local machine_id
  local score
  local best_id=""
  local best_score=0
  local best_count=0

  if [[ -n "$forced" ]]; then
    printf '%s\n' "$forced"
    return 0
  fi

  if [[ "${WTMUX_LOCAL_MACHINE_ID_CACHE_INITIALIZED:-0}" == "1" ]]; then
    [[ -n "${WTMUX_LOCAL_MACHINE_ID_CACHE:-}" ]] || return 1
    printf '%s\n' "$WTMUX_LOCAL_MACHINE_ID_CACHE"
    return 0
  fi

  for machine_id in "${WTMUX_MACHINE_IDS[@]:-}"; do
    score="$(wtmux_local_machine_score "$machine_id" 0)"
    if (( score > best_score )); then
      best_id="$machine_id"
      best_score="$score"
      best_count=1
    elif (( score == best_score && score > 0 )); then
      best_count=$((best_count + 1))
    fi
  done

  if (( best_score < 4 || best_count != 1 )); then
    best_id=""
    best_score=0
    best_count=0
    for machine_id in "${WTMUX_MACHINE_IDS[@]:-}"; do
      score="$(wtmux_local_machine_score "$machine_id" 1)"
      if (( score > best_score )); then
        best_id="$machine_id"
        best_score="$score"
        best_count=1
      elif (( score == best_score && score > 0 )); then
        best_count=$((best_count + 1))
      fi
    done
  fi

  WTMUX_LOCAL_MACHINE_ID_CACHE_INITIALIZED=1
  if (( best_score >= 4 && best_count == 1 )); then
    WTMUX_LOCAL_MACHINE_ID_CACHE="$best_id"
    printf '%s\n' "$best_id"
    return 0
  fi

  WTMUX_LOCAL_MACHINE_ID_CACHE=""
  return 1
}

wtmux_write_machine_record() {
  local machine_id="$1"
  local machine_name="$2"
  local roles="$3"
  local platform="$4"
  local linux_username="$5"
  local tailscale_node="$6"
  local projects_root="$7"
  local transport="$8"
  local wsl_distro="$9"
  local fallback_ssh_host="${10}"
  local fallback_identity_file="${11}"
  local fallback_ip="${12}"
  local host_command="${13:-wtmux-host}"
  local record_path

  mkdir -p "$(wtmux_shared_registry_dir)"
  if [[ -n "$fallback_identity_file" ]]; then
    wtmux_warn "fallback identity files are machine-local and cannot be written to the shared JSON registry"
    return 1
  fi
  command -v python3 >/dev/null 2>&1 || {
    wtmux_warn "writing a machine record requires python3"
    return 1
  }
  record_path="$(wtmux_shared_machine_record_path "$machine_id")"
  python3 "$(wtmux_registry_tool_path)" write-machine \
    --output "$record_path" \
    --id "$machine_id" \
    --name "$machine_name" \
    --roles "$roles" \
    --platform "$platform" \
    --linux-username "$linux_username" \
    --tailscale-node "$tailscale_node" \
    --projects-root "$projects_root" \
    --transport "$transport" \
    --wsl-distro "$wsl_distro" \
    --fallback-ssh-host "$fallback_ssh_host" \
    --fallback-ip "$fallback_ip" \
    --host-command "$host_command" >/dev/null
}

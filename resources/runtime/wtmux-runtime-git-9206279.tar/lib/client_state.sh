#!/usr/bin/env bash

if [[ -n "${WTMUX_LIB_CLIENT_STATE_SH:-}" ]]; then
  return 0
fi
WTMUX_LIB_CLIENT_STATE_SH=1

source "${WTMUX_REPO_ROOT}/lib/common.sh"

wtmux_client_state_dir() {
  printf '%s/client\n' "$(wtmux_state_dir)"
}

wtmux_client_state_path() {
  local key="$1"
  printf '%s/%s\n' "$(wtmux_client_state_dir)" "$key"
}

wtmux_client_state_write() {
  local key="$1"
  local value="$2"
  local path

  path="$(wtmux_client_state_path "$key")"
  mkdir -p "$(dirname "$path")"
  printf '%s\n' "$value" >"$path"
}

wtmux_client_state_read() {
  local key="$1"
  local path
  local value

  path="$(wtmux_client_state_path "$key")"
  [[ -f "$path" ]] || return 1
  IFS= read -r value <"$path" || return 1
  [[ -n "$value" ]] || return 1
  printf '%s\n' "$value"
}

wtmux_client_state_record_attach() {
  local host_id="$1"
  local project_name="$2"
  local session_name="$3"

  wtmux_client_state_write "last-host" "$host_id"
  wtmux_client_state_write "last-project" "$project_name"
  wtmux_client_state_write "last-session" "$session_name"
}

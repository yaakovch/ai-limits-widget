# Agent Fleet Contracts

This directory is the canonical, topology-independent contract package for the
Agent Fleet product. Until migration activation, wtmux owns the package and the
Windows and Android repositories consume byte-identical fixture mirrors pinned
by `contract-lock-v1.json`.

Rules:

- `manifest-v1.json` is the package index and protocol/unknown-field policy.
- `limits-v1.json` owns structural size and count limits shared by consumers.
- `privacy-v1.json` classifies channels and forbidden persisted content.
- `compatibility-v1.json` records current component/protocol compatibility.
- `supervisor-v1.schema.json` and its conformance fixture define the shared
  client lifecycle, resource bounds, backpressure, and channel failure domains
  without prescribing a platform process implementation.
- `transport-v1.schema.json` defines engine capabilities, stable failures,
  recovery actions, direct-network opt-in, and the measured adoption state of
  OpenSSH convergence, connection reuse, and SFTP.
- `schemas/` contains JSON Schema 2020-12 structural contracts.
- `generated/` contains deterministic structural catalogs and Python,
  TypeScript, and Kotlin models produced by
  `scripts/integration/generate-contract-models`.
- `fixtures/valid/` and `fixtures/invalid/` contain bounded conformance cases.
- JSON schemas do not replace handwritten trust, identity, path, revision,
  authorization, privacy, or state-transition validation.
- Control v1 and conversation v2 reject unknown fields. Additive fields require
  a negotiated protocol/capability or a documented compatibility exception.
- Generated models and mirrors must never be edited directly; regenerate them
  from this package. The generator also rebuilds the package lock and mirrors
  that lock and every conformance fixture to both supplied client roots.

The old `fleet/schema/` files remain compatibility mirrors during migration.
Tests require them to be byte-identical to their canonical counterparts.

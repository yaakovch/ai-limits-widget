#!/usr/bin/env bash

if [[ -n "${WTMUX_LIB_TAILSCALE_SH:-}" ]]; then
  return 0
fi
WTMUX_LIB_TAILSCALE_SH=1

source "${WTMUX_REPO_ROOT}/lib/common.sh"

wtmux_has_tailscale() {
  command -v tailscale >/dev/null 2>&1
}

wtmux_local_tailscale_node() {
  if [[ "${WTMUX_LOCAL_TAILSCALE_NODE_CACHE_INITIALIZED:-0}" == "1" ]]; then
    [[ -n "${WTMUX_LOCAL_TAILSCALE_NODE_CACHE:-}" ]] || return 1
    printf '%s\n' "$WTMUX_LOCAL_TAILSCALE_NODE_CACHE"
    return 0
  fi

  local node
  WTMUX_LOCAL_TAILSCALE_NODE_CACHE_INITIALIZED=1
  wtmux_has_tailscale || return 1
  node="$(tailscale status --json 2>/dev/null | awk -F'"' '/"DNSName"/ {gsub(/\.$/, "", $4); print $4; exit}')"
  WTMUX_LOCAL_TAILSCALE_NODE_CACHE="$node"
  [[ -n "$node" ]] || return 1
  printf '%s\n' "$node"
}

wtmux_tailscale_peer_ip() {
  local peer="$1"
  local ip=""
  local short_peer=""

  wtmux_has_tailscale || return 1
  ip="$(tailscale ip -4 "$peer" 2>/dev/null | head -n 1)"
  if [[ -z "$ip" && "$peer" == *.* ]]; then
    short_peer="${peer%%.*}"
    ip="$(tailscale ip -4 "$short_peer" 2>/dev/null | head -n 1)"
  fi
  [[ -n "$ip" ]] || return 1
  printf '%s\n' "$ip"
}

wtmux_build_tailscale_ssh_command() {
  local target_var="$1"
  local -n out_ref="$target_var"
  local remote_target="$2"
  shift 2
  # `tailscale ssh -- cmd ...` preserves argv directly, which avoids the
  # `bash -lc` re-parsing bug that dropped subcommands like `projects`.
  out_ref=("tailscale" "ssh" "${remote_target}" "--" "$@")
}

#!/usr/bin/env bash
set -euo pipefail

SELF="${BASH_SOURCE[0]}"
while [[ -L "$SELF" ]]; do
  DIR="$(cd -P "$(dirname "$SELF")" >/dev/null 2>&1 && pwd)"
  TARGET="$(readlink "$SELF")"
  if [[ "$TARGET" != /* ]]; then
    SELF="${DIR}/${TARGET}"
  else
    SELF="$TARGET"
  fi
done
SCRIPT_DIR="$(cd -P "$(dirname "$SELF")" >/dev/null 2>&1 && pwd)"
WTMUX_REPO_ROOT="$(cd -P "${SCRIPT_DIR}" >/dev/null 2>&1 && pwd)"

source "${WTMUX_REPO_ROOT}/lib/common.sh"
source "${WTMUX_REPO_ROOT}/lib/platform.sh"
source "${WTMUX_REPO_ROOT}/lib/config.sh"
source "${WTMUX_REPO_ROOT}/lib/vscode.sh"

REPAIR=0
REFRESH_ONLY=0
NO_HOOKS=0
INSTALL_DEPS=0
NO_INSTALL_DEPS=0
MACHINE_ID=""

while (($# > 0)); do
  case "$1" in
    --install-deps)
      INSTALL_DEPS=1
      shift
      ;;
    --no-install-deps)
      NO_INSTALL_DEPS=1
      shift
      ;;
    --repair)
      REPAIR=1
      shift
      ;;
    --refresh-only)
      REFRESH_ONLY=1
      shift
      ;;
    --no-hooks)
      NO_HOOKS=1
      shift
      ;;
    --machine)
      MACHINE_ID="$2"
      shift 2
      ;;
    -h|--help)
      cat <<'EOF'
Usage: setup.sh [--install-deps] [--no-install-deps] [--repair] [--refresh-only] [--machine ID] [--no-hooks]
EOF
      exit 0
      ;;
    *)
      wtmux_die "unknown setup flag: $1"
      ;;
  esac
done

wtmux_setup_install_dependencies() {
  local platform
  local requested_install=0
  requested_install="${1:-0}"
  platform="$(wtmux_detect_platform)"

  if [[ "$requested_install" != "1" ]] && [[ "$REFRESH_ONLY" == "1" ]]; then
    return 0
  fi

  case "$platform" in
    termux)
      command -v pkg >/dev/null 2>&1 || wtmux_die "Termux package manager not found: pkg"
      pkg update -y
      pkg install -y git openssh tmux fzf python termux-api
      ;;
    linux|wsl)
      command -v apt-get >/dev/null 2>&1 || wtmux_die "automatic dependency install currently requires apt-get"
      command -v sudo >/dev/null 2>&1 || wtmux_die "automatic dependency install requires sudo"
      sudo apt-get update
      sudo apt-get install -y git openssh-client tmux fzf curl ca-certificates bats python3
      if ! command -v tailscale >/dev/null 2>&1; then
        wtmux_info "installing Tailscale CLI via the official install script"
        curl -fsSL https://tailscale.com/install.sh | sudo sh
      fi
      ;;
    *)
      wtmux_die "unsupported platform for dependency install: ${platform}"
      ;;
  esac
}

wtmux_setup_missing_commands() {
  local platform
  local required=()
  local missing=()
  local cmd

  platform="$(wtmux_detect_platform)"
  required=(git ssh tmux fzf python3)
  if [[ "$platform" != "termux" ]]; then
    required+=(tailscale)
  fi

  for cmd in "${required[@]}"; do
    if ! command -v "$cmd" >/dev/null 2>&1; then
      missing+=("$cmd")
    fi
  done

  printf '%s\n' "${missing[@]:-}"
}

wtmux_setup_warn_missing_dependencies() {
  local missing
  missing="$(wtmux_setup_missing_commands)"
  [[ -n "$missing" ]] || return 0

  wtmux_warn "missing dependency command(s): $(printf '%s' "$missing" | paste -sd ' ' -)"
  wtmux_warn "run './setup.sh --install-deps' from this checkout to install supported dependencies"
}

wtmux_setup_ensure_dependencies() {
  local missing

  if [[ "$NO_INSTALL_DEPS" == "1" ]]; then
    wtmux_setup_warn_missing_dependencies
    return 0
  fi

  missing="$(wtmux_setup_missing_commands)"
  if [[ -z "$missing" && "$INSTALL_DEPS" != "1" ]]; then
    return 0
  fi

  # Git hooks use refresh-only and must never imply that they are performing a
  # package-manager mutation. The final warning below tells the user how to
  # install anything that is missing.
  if [[ "$REFRESH_ONLY" == "1" && "$INSTALL_DEPS" != "1" ]]; then
    return 0
  fi

  if [[ -n "$missing" ]]; then
    wtmux_info "installing missing dependency command(s): $(printf '%s' "$missing" | paste -sd ' ' -)"
  else
    wtmux_info "checking supported dependencies"
  fi
  wtmux_setup_install_dependencies "$INSTALL_DEPS"
}

wtmux_setup_print_postinstall_notes() {
  local platform
  platform="$(wtmux_detect_platform)"

  if [[ "$platform" != "termux" ]]; then
    if command -v tailscale >/dev/null 2>&1 && ! tailscale status >/dev/null 2>&1; then
      wtmux_warn "Tailscale is installed but not ready; run 'sudo tailscale up' and authenticate this machine"
    fi
  fi

  if [[ ":${PATH}:" != *":${HOME}/.local/bin:"* && -d "${HOME}/.local/bin" ]]; then
    wtmux_warn "${HOME}/.local/bin is not on PATH; add 'export PATH=\"\$HOME/.local/bin:\$PATH\"' to your shell profile or open a new shell"
  fi
}

wtmux_setup_configure_vscode_tabs() {
  wtmux_vscode_configure_terminal_tabs || true
  case "$WTMUX_VSCODE_SETTINGS_STATUS" in
    updated)
      wtmux_info "configured VS Code terminal tab titles in ${WTMUX_VSCODE_SETTINGS_RESOLVED_PATH}"
      ;;
    configured)
      wtmux_debug "VS Code terminal tab titles already configured in ${WTMUX_VSCODE_SETTINGS_RESOLVED_PATH}"
      ;;
    not-detected)
      wtmux_debug "VS Code user settings were not detected; skipping terminal tab title setup"
      ;;
    error)
      wtmux_warn "could not safely update VS Code settings at ${WTMUX_VSCODE_SETTINGS_RESOLVED_PATH}"
      ;;
  esac
  return 0
}

wtmux_setup_ensure_dependencies

install_link() {
  local name="$1"
  local source_path="$2"
  local target_path
  local resolved_target

  target_path="$(wtmux_runtime_bin_dir)/${name}"
  mkdir -p "$(dirname "$target_path")"

  if [[ -L "$target_path" ]]; then
    resolved_target="$(readlink -f "$target_path" 2>/dev/null || true)"
    if [[ "$resolved_target" == "$source_path" ]]; then
      return 0
    fi
    if [[ "$REPAIR" == "1" || "$REFRESH_ONLY" == "1" ]]; then
      wtmux_warn "refreshing stale launcher ${target_path}"
      ln -snf "$source_path" "$target_path"
    else
      wtmux_warn "launcher ${target_path} points at a different checkout; rerun setup with --repair to replace it"
    fi
    return 0
  fi

  if [[ -e "$target_path" ]]; then
    wtmux_warn "skipping ${target_path} because it is not a symlink"
    return 0
  fi

  ln -snf "$source_path" "$target_path"
}

ensure_projects_root() {
  local machine_id="$1"
  local projects_root

  [[ -n "$machine_id" ]] || return 0
  wtmux_require_config "$(wtmux_config_path)"
  if wtmux_machine_has_role "$machine_id" "host"; then
    projects_root="$(wtmux_machine_field "$machine_id" "projects_root")"
    [[ -n "$projects_root" ]] && mkdir -p "$projects_root"
  fi
}

mkdir -p "$(wtmux_runtime_bin_dir)"
mkdir -p "$(dirname "$(wtmux_config_path)")"
mkdir -p "$(wtmux_state_dir)"
mkdir -p "$(wtmux_cache_dir)"
mkdir -p "$(wtmux_shared_registry_dir)"

if [[ ! -f "$(wtmux_config_path)" ]]; then
  wtmux_write_default_config "$(wtmux_config_path)"
fi

wtmux_ensure_runtime_config_uses_shared_registry "$(wtmux_config_path)"
wtmux_load_config "$(wtmux_config_path)"

install_link "wtmux" "${WTMUX_REPO_ROOT}/scripts/wtmux"
install_link "wtmux-host" "${WTMUX_REPO_ROOT}/scripts/wtmux-host"
install_link "wtmux-host-runtime" "${WTMUX_REPO_ROOT}/scripts/wtmux-host-runtime"
install_link "wtmux-agent" "${WTMUX_REPO_ROOT}/scripts/wtmux-agent"
install_link "wtmux-bridge" "${WTMUX_REPO_ROOT}/scripts/wtmux-bridge"
install_link "wtmux-conversation" "${WTMUX_REPO_ROOT}/scripts/wtmux-conversation"
install_link "wtmux-directory" "${WTMUX_REPO_ROOT}/scripts/wtmux-directory"
install_link "wtmux-files" "${WTMUX_REPO_ROOT}/scripts/wtmux-files"
install_link "wtmux-pair-client" "${WTMUX_REPO_ROOT}/scripts/wtmux-pair-client"
install_link "wtmux-pairing" "${WTMUX_REPO_ROOT}/scripts/wtmux-pairing"
install_link "wtmux-registry" "${WTMUX_REPO_ROOT}/scripts/wtmux-registry"
install_link "wtmux-runtime" "${WTMUX_REPO_ROOT}/scripts/wtmux-runtime"
install_link "wtmux-runtime-release" "${WTMUX_REPO_ROOT}/scripts/wtmux-runtime-release"
install_link "agent-fleet-release-set" "${WTMUX_REPO_ROOT}/scripts/agent-fleet-release-set"
install_link "wtmux-scheduler" "${WTMUX_REPO_ROOT}/scripts/wtmux-scheduler"
install_link "wtmux-shell" "${WTMUX_REPO_ROOT}/scripts/wtmux-shell"
install_link "wtmux-settings" "${WTMUX_REPO_ROOT}/scripts/wtmux-settings"
install_link "wtmux-client-policy" "${WTMUX_REPO_ROOT}/scripts/wtmux-client-policy"

if command -v python3 >/dev/null 2>&1 && tmux list-sessions >/dev/null 2>&1; then
  scheduler_setup_output="$(WTMUX_SCHEDULE_AUTO_DETECT="${WTMUX_SCHEDULE_AUTO_DETECT:-1}" \
    python3 "${WTMUX_REPO_ROOT}/scripts/wtmux-scheduler" configure 2>/dev/null || true)"
  if [[ "$scheduler_setup_output" == *"binding=preserved"* ]]; then
    scheduler_warning_marker="$(wtmux_state_dir)/scheduler/prefix-s-binding-warning"
    if [[ ! -e "$scheduler_warning_marker" ]]; then
      wtmux_warn "tmux Prefix+S already has a non-wtmux binding; scheduled messages remain available through wtmux-host schedule ui"
      mkdir -p "$(dirname "$scheduler_warning_marker")"
      : >"$scheduler_warning_marker"
      chmod 600 "$scheduler_warning_marker"
    fi
  elif [[ -n "$scheduler_setup_output" ]]; then
    wtmux_info "configured scheduled-message support (${scheduler_setup_output})"
  fi
fi

if [[ "$NO_HOOKS" != "1" ]] && git -C "$WTMUX_REPO_ROOT" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  git -C "$WTMUX_REPO_ROOT" config core.hooksPath .githooks
fi

if [[ "$(wtmux_detect_platform)" == "termux" ]]; then
  termux_bash="$(command -v bash)"
  [[ "$termux_bash" == /*/bin/bash ]] || wtmux_die "could not resolve the active Termux bash prefix"
  termux_prefix="${termux_bash%/bin/bash}"
  mkdir -p "${HOME}/.shortcuts"
  cat >"${HOME}/.shortcuts/wtmux" <<EOF
#!${termux_bash}
export PATH="${termux_prefix}/bin:\${HOME}/.local/bin:\${PATH}"
exec "${termux_bash}" "${termux_prefix}/bin/wtmux" "\$@"
EOF
  chmod 700 "${HOME}/.shortcuts/wtmux"
fi

ensure_projects_root "$MACHINE_ID"
wtmux_setup_configure_vscode_tabs
wtmux_setup_warn_missing_dependencies
wtmux_setup_print_postinstall_notes
wtmux_info "setup complete"

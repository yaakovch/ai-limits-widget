#!/usr/bin/env bash

if [[ -n "${WTMUX_LIB_PICKER_SH:-}" ]]; then
  return 0
fi
WTMUX_LIB_PICKER_SH=1

source "${WTMUX_REPO_ROOT}/lib/common.sh"

wtmux_picker_backend() {
  if [[ -n "${WTMUX_PICKER_BACKEND:-}" ]]; then
    printf '%s\n' "$WTMUX_PICKER_BACKEND"
    return 0
  fi
  if command -v fzf >/dev/null 2>&1; then
    printf '%s\n' "fzf"
  elif command -v gum >/dev/null 2>&1; then
    printf '%s\n' "gum"
  else
    printf '%s\n' "text"
  fi
}

wtmux_picker_supports_action_keys() {
  [[ "$(wtmux_picker_backend)" == "fzf" ]]
}

wtmux_pick_action_menu_option() {
  local prompt="$1"
  local __result_var="$2"
  local __action_var="$3"
  local allow_back="${4:-0}"
  shift 4
  local options=("$@")
  local labels=()
  local option
  local label
  local value
  local pick_output=""
  local pick_status=0
  local pressed_key=""
  local choice=""
  local header="Enter: open | Ctrl+O: more | Ctrl+X: kill"

  if ! wtmux_picker_supports_action_keys; then
    if wtmux_pick_menu_option "$prompt" "$__result_var" "$allow_back" "${options[@]}"; then
      printf -v "$__action_var" '%s' "select"
      return 0
    else
      pick_status=$?
    fi
    return "$pick_status"
  fi

  if [[ "$allow_back" == "1" ]]; then
    options+=("Back|__wtmux_back__")
    header+=" | Esc: back"
  fi

  [[ "${#options[@]}" -gt 0 ]] || return 1
  for option in "${options[@]}"; do
    labels+=("${option%|*}")
  done

  if pick_output="$(printf '%s\n' "${labels[@]}" | fzf \
    --expect=esc,ctrl-c,ctrl-o,ctrl-x \
    --header "$header" \
    --prompt "${prompt}> " \
    --height 40%)"; then
    :
  else
    pick_status=$?
    (( pick_status == 130 )) && return 130
    if [[ "$allow_back" == "1" ]]; then
      return 2
    fi
    return "$pick_status"
  fi

  pressed_key="${pick_output%%$'\n'*}"
  case "$pressed_key" in
    esc)
      return 2
      ;;
    ctrl-c)
      return 130
      ;;
    ctrl-x)
      printf -v "$__action_var" '%s' "kill"
      ;;
    ctrl-o)
      printf -v "$__action_var" '%s' "more"
      ;;
    *)
      printf -v "$__action_var" '%s' "select"
      ;;
  esac

  if [[ "$pick_output" == *$'\n'* ]]; then
    choice="${pick_output#*$'\n'}"
    choice="${choice%%$'\n'*}"
  else
    return 1
  fi

  for option in "${options[@]}"; do
    label="${option%|*}"
    value="${option##*|}"
    if [[ "$label" == "$choice" ]]; then
      if [[ "$value" == "__wtmux_back__" && "$pressed_key" != "ctrl-x" ]]; then
        return 2
      fi
      printf -v "$__result_var" '%s' "$value"
      return 0
    fi
  done

  return 1
}

wtmux_pick_menu_option() {
  local prompt="$1"
  local __result_var="$2"
  local allow_back="${3:-0}"
  shift 3
  local options=("$@")
  local labels=()
  local option
  local choice=""
  local index=1
  local label
  local value
  local backend
  local pick_output
  local pick_status
  local key

  if [[ "$allow_back" == "1" ]]; then
    options+=("Back|__wtmux_back__")
  fi

  if [[ "${#options[@]}" -eq 0 ]]; then
    return 1
  fi

  for option in "${options[@]}"; do
    labels+=("${option%|*}")
  done

  backend="$(wtmux_picker_backend)"
  case "$backend" in
    gum)
      if pick_output="$(printf '%s\n' "${labels[@]}" | gum filter --limit=1 --select-if-one --header "$prompt" --placeholder "Type to filter")"; then
        choice="$pick_output"
      else
        pick_status=$?
        if (( pick_status == 130 )); then
          return 130
        fi
        if [[ "$allow_back" == "1" ]]; then
          return 2
        fi
        return "$pick_status"
      fi
      ;;
    fzf)
      if [[ "$allow_back" == "1" ]]; then
        if pick_output="$(printf '%s\n' "${labels[@]}" | fzf --expect=esc,ctrl-c --prompt "${prompt}> " --height 40%)"; then
          key="${pick_output%%$'\n'*}"
          if [[ "$key" == "esc" ]]; then
            return 2
          fi
          if [[ "$key" == "ctrl-c" ]]; then
            return 130
          fi
          if [[ "$pick_output" == *$'\n'* ]]; then
            choice="${pick_output#*$'\n'}"
            choice="${choice%%$'\n'*}"
          else
            choice="$pick_output"
          fi
        else
          pick_status=$?
          if (( pick_status == 130 )); then
            return 130
          fi
          return 2
        fi
      else
        choice="$(printf '%s\n' "${labels[@]}" | fzf --prompt "${prompt}> " --height 40%)" || return 1
      fi
      ;;
    *)
      if ! wtmux_is_interactive; then
        return 1
      fi
      printf '%s\n' "$prompt" >&2
      for label in "${labels[@]}"; do
        printf '  %d) %s\n' "$index" "$label" >&2
        index=$((index + 1))
      done
      if ! read -r -p "> " choice; then
        return 130
      fi
      if [[ "$allow_back" == "1" && ( "$choice" == "0" || "${choice,,}" == "b" || "${choice,,}" == "back" ) ]]; then
        return 2
      fi
      if [[ "$choice" =~ ^[0-9]+$ ]] && (( choice >= 1 && choice <= ${#options[@]} )); then
        choice="${labels[$((choice - 1))]}"
      else
        return 1
      fi
      ;;
  esac

  for option in "${options[@]}"; do
    label="${option%|*}"
    value="${option##*|}"
    if [[ "$label" == "$choice" ]]; then
      if [[ "$value" == "__wtmux_back__" ]]; then
        return 2
      fi
      printf -v "$__result_var" '%s' "$value"
      return 0
    fi
  done

  return 1
}

wtmux_pick_option() {
  local prompt="$1"
  local __result_var="$2"
  shift 2
  local pick_status=0

  if wtmux_pick_menu_option "$prompt" "$__result_var" "0" "$@"; then
    return 0
  else
    pick_status=$?
    if (( pick_status == 130 )); then
      return 130
    fi
  fi
  return 1
}

wtmux_prompt_input() {
  local prompt="$1"
  local __result_var="$2"
  local default_value="${3:-}"
  local backend
  local input=""

  backend="$(wtmux_picker_backend)"
  case "$backend" in
    gum)
      input="$(gum input --prompt "${prompt}: " --value "$default_value")" || return 1
      ;;
    *)
      if ! wtmux_is_interactive; then
        return 1
      fi
      read -r -p "${prompt}${default_value:+ [${default_value}]}: " input
      input="${input:-$default_value}"
      ;;
  esac

  printf -v "$__result_var" '%s' "$input"
}

wtmux_confirm() {
  local prompt="$1"
  local backend
  local answer

  backend="$(wtmux_picker_backend)"
  case "$backend" in
    gum)
      gum confirm "$prompt"
      ;;
    *)
      if ! wtmux_is_interactive; then
        return 1
      fi
      read -r -p "${prompt} [y/N]: " answer
      [[ "${answer,,}" == "y" || "${answer,,}" == "yes" ]]
      ;;
  esac
}
